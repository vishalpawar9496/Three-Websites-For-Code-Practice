
<div class="4u">
						<h2><a href=""> 
                        </a>update your profile and get more information about</h2>
						<ul class="list-style2">
						  <li class="first"><img src="images/ping4.jpg" width="59" height="59" alt="">Job and training information about IT</li>
							<li><img src="images/ping2.jpg" width="59" height="59" alt="">jobs and training information about banking							</li>
							<li><img src="images/phar.jpg" width="59" height="59" alt="">jobs and training information about pharamcy</li>
                            				<li><img src="images/real.jpg" width="59" height="59" alt="">jobs and training information about Real Estate</li>
                                            				<li><img src="images/ele.jpg" width="59" height="59" alt="">jobs and training information about electronics</li>
								<p class="posted">&nbsp;</p>
							</li>
						</ul>
					</div>