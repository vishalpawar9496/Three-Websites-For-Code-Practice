<?php

if(isset($_REQUEST['name'],$_REQUEST['name2']))
{
	echo $_REQUEST['name'];
	$_REQUEST['name2'];
	}
?>
<br/><br/><br/><br/><center><h1>someone already use this username try another</h1></center>