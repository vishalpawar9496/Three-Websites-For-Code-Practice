<!DOCTYPE HTML>
<!--
	Iridium: A responsive HTML5 website template by HTML5Templates.com
	Released for free under the Creative Commons Attribution 3.0 license (html5templates.com/license)
	Visit http://html5templates.com for more great templates or follow us on Twitter @HTML5T
-->
<html>
<head>
<title>Training and Career related Information for Bangladesh</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<noscript>
<link rel="stylesheet" href="css1/5grid/core.css" />
<link rel="stylesheet" href="css1/5grid/core-desktop.css" />
<link rel="stylesheet" href="css1/5grid/core-1200px.css" />
<link rel="stylesheet" href="css1/5grid/core-noscript.css" />
<link rel="stylesheet" href="css1/style.css" />
<link rel="stylesheet" href="css1/style-desktop.css" />
</noscript>
<script src="css1/5grid/jquery.js"></script>
<script src="css1/5grid/init.js?use=mobile,desktop,1000px&amp;mobileUI=1&amp;mobileUI.theme=none"></script>
<!--[if IE 9]><link rel="stylesheet" href="css1/style-ie9.css" /><![endif]-->
</head><body>
<div id="header-wrapper">
	<header id="header" class="5grid-layout"><center><font size="+2" ><img src="images/icon.png" width="192" height="63" longdesc="images/icon.png">Training and Career related Information for Bangladesh</font></center>
		<div class="row">
			<div class="12u"> 
				<!-- Logo -->
				<h1></h1>
				<!-- Nav -->
			  <nav class="mobileUI-site-nav"> <a href="#" class="active"></a><a href="logout.php?asd=<?php echo $a;?>">logout</a> <a href="onecolumn.html"></a></nav>
            
			</div>
		</div>
	</header>
</div>