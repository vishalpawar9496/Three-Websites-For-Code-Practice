# final-year-project
It's my final year project of my bachelor study in 2014. This project is completely developed with php/mysql, bootstrap, html and css.here i didn't use any framework so the whole project is developed with pure php script with oop feature, this is a very large project and it shows how to build a big project without the use of any framework. This project is on “Training and career related information for Bangladesh”. This is a kind of study that shows the new dimension of categorized training and career
information on different basis required by human being through web based application.
This portal contains categorized course and career along with
different type’s information that people would need to improve their career. Generously
it’s little bit tough to get basic information that required for any purpose in a single
website. People have to browse for their own requirements to different websites with
different addresses. It’s time consuming and hard to memorize addresses. But in TCIB
people have to browse and choose their required category for training and career
information. By reading training information a reader could report on the posted
information. Only admin could see that the comment and also post their individual
opinion on that particular report. Hence interaction between various types of human
thinking could furnish through TCIB.
